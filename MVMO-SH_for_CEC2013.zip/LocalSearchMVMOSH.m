function [FUN,g,xn_out,FEVALS,exitflag] = LocalSearchMVMOSH(xx_yy1,func_num)

global parameter 
global obj_func_ref  


lb=parameter.x_min;
ub=parameter.x_max;
Aeq=[]; %AeqX=Beq
Beq=[];
A=[]; %AX<=B
B=[];

%Denormalize to the original [min, max] range 
xx_yy = parameter.x_min+parameter.scaling.* xx_yy1;

     options=optimset('Display','off','algorithm','interior-point','UseParallel','never'); 

[Xsqp, FUN , exitflag, output] = ...
    fmincon(@(xx_yy)LSearch(xx_yy,obj_func_ref,func_num),xx_yy,A,B,Aeq,Beq,lb,ub,[],options);

FEVALS=output.funcCount;
for nvar=1:size(xx_yy,2)
    if isnan(Xsqp(1,nvar))
        Xsqp=xx_yy;
        break;
    end
end
g=0;

% Normalize again to [0, 1]
xn_out = (Xsqp-parameter.x_min)./parameter.scaling;


function J=LSearch(xx_yy,obj_func_ref,func_num)

fhd=str2func('cec13_func');

J1 = feval(fhd,xx_yy',func_num)-obj_func_ref(func_num);

if abs(J1)<=1.d-8
    J=0.d0 ;
else
    J=J1;
end




