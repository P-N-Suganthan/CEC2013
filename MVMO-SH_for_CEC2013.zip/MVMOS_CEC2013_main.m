%==========================================================================
%     MVMOS-based solution for CEC 2013 Special Session and Competition 
%                   on Real-Parameter Optimization
%==========================================================================

%                                  Reference
%--------------------------------------------------------------------------
% [1] J. J. Liang, B. Y. Qu, and P. N. Suganthan, "Problem Definitions and 
%     Evaluation Criteria for the CEC 2013 Special Session and Competition
%     on Real-Parameter Optimization"
% [Online] Available at http://www.ntu.edu.sg/home/EPNSugan/index_files/CEC2013/CEC2013.htm
%--------------------------------------------------------------------------

%By: Dr.-Ing. Jos� L. Rueda & Prof. Istv�n Erlich
%10.06.2013 

close all
clear all
clc


global parameter 
global printff sn 
global obj_func_ref


%                  Define parameters of the optimization problem
%--------------------------------------------------------------------------
D=10; %30;  %Problem dimension
Xmin=-100;  
Xmax=100;   
VRmin=repmat(Xmin,1,D);
VRmax=repmat(Xmax,1,D);
%Min and max limits of control variables
parameter.x_min = VRmin; 
parameter.x_max = VRmax; 
parameter.scaling = (parameter.x_max-parameter.x_min);  
obj_func_ref=[-1400:100:-100,100:100:1400]'; %Theoretical optimum value
%--------------------------------------------------------------------------


%                        Define MVMO-SH parameters
%--------------------------------------------------------------------------
%Logic control for screen printing
sn = true;
%Max no. of function evaluations
parameter.MaxEval = 10000*D;
%Print results at every printff function evaluation on the screen
printff = round(parameter.MaxEval/100) ;
%Parameter record step
parameter.rec_step = [0.01,0.1:0.1:1];
%Problem dimension
parameter.n_var = D; 

% Regular MVMO-SH control
parameter.n_par = 15*D; %Number of particles          
parameter.n_tosave = 5; %Size of the solution archive
parameter.n_random_ini = round(D/2)+1; %Initial number of variables selected for mutation
parameter.n_random_last = 1; %%Initial number of variables selected for mutation
parameter.Indep_run = 2; %Independent evaluation of every particle.                      

% Advanced MVMO-SH control
%Selection strategy for offspring creation [1,2,3,4,5]: 
%1-Random, 2-Neighbor group block stepping, 3-Neighbor group single stepping
%4-Sequential random selection, 5-Roulette tournament
parameter.mode =4; 
parameter.fs_factor_start = 1; %Initial shape scaling factor
parameter.fs_factor_end =  20; %Final shape scaling factor
parameter.dddd = 1d0; %Initial value of alternative shape
parameter.delta_dddd_start = 0.05; %Initial scale factor for alternative shape 
parameter.delta_dddd_end = 0.05; %Final scale factor for alternative shape 
%Decrement strategy of variables selected for mutation: [1,2,3]:
%1-Linear, 2-Quadratic progressive, 3-Quadratic degressive
%plus 40 means variable randomly changed within the range
parameter.nrand_method =41; 
%--------------------------------------------------------------------------


runs=51; %Repetitions of the optimization
problem_filename_stats=strcat('mvmo_statistics_', num2str(D));
problem_filename_stats1=strcat(problem_filename_stats,'.txt');

mvmos_fbest=zeros(1+1/parameter.rec_step(2),runs);
mvmos_xbest=zeros(runs,D);
mvmos_trun=zeros(runs,1);
fbest_stats=zeros(28,5);
fnum_count=zeros(28,1);

for func_num=1:28 %Problem number
    
    rand('state',sum(100*clock));
  
    problem_filename=strcat('mvmo_', num2str(func_num));
    problem_filename1=strcat(problem_filename, '_');
    problem_filename2=strcat(problem_filename1, num2str(D));
    problem_filename2a=strcat(problem_filename2, '_variables');
    problem_filename2b=strcat(problem_filename2, '_time');
    problem_filename3=strcat(problem_filename2,'.txt');
    problem_filename3a=strcat(problem_filename2a,'.txt');
    problem_filename3b=strcat(problem_filename2b,'.txt');
    
       
    for j=1:runs %Run number     
        
        tStart = tic;
        [ofcn,best,exitflag]=MVMOS_SH('test_func_all_cec2013',j,func_num);
        trun1=toc(tStart);
        
        mvmos_fbest(:,j)=ofcn;
        mvmos_xbest(j,:)=best;
        mvmos_trun(j,:)=trun1;
               
    end
    
    save(problem_filename3, 'mvmos_fbest','-ASCII')
    save(problem_filename3a, 'mvmos_xbest','-ASCII')
    save(problem_filename3b, 'mvmos_trun','-ASCII')
      
    fbest_stats(func_num,:)=[min(mvmos_fbest(end,:)),max(mvmos_fbest(end,:)),median(mvmos_fbest(end,:)),mean(mvmos_fbest(end,:)),std(mvmos_fbest(end,:))];
    fnum_count(func_num,:)=func_num;
    
end

fbest_stats=[fnum_count, fbest_stats];

save(problem_filename_stats1, 'fbest_stats','-ASCII')


