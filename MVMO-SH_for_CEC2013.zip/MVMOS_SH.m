 function [ofcn,best,exitflag_count] = MVMOS_SH(fhd,repcont,varargin)
    %By:  
    %    Dr. Jose L. Rueda (jose.rueda@uni-duisburg-essen.de)
    %    Prof. Istvan Erlich (istvan.erlich@uni-due.de)
    % Hybrid variant of the Mean-Variance Mapping Optimization (MVMO-SH) - Version 2013 �
    %              -------------------*-------------------

    %              -------------------*-------------------
    %============================== Nomenclature ==============================
    % max_eval :=  Maximum number of objective function evaluations
    % n_var := Number of parameters to be optimized, i.e. the dimensionality of the problem.
    % n_par := Number of particles
    % n_to_save := Size of the solution archive
    % n_randomly_ini := Initial number of variables selected for mutation 
    % n_randomly_last := Minimum number of variables selected for mutation
    % Indep_run := Independent evaluation of every particle
    % mode := Selection strategy for offspring creation
    % fs_factor_start := Initial shape scaling factor
    % fs_factor_end := Final shape scaling factor
    % dddd := Initial value of alternative shape 
    % delta_dddd_start := Initial scale factor for alternative shape 
    % delta_dddd_end := Final scale factor for alternative shape
    % nrand_method := Decrement strategy of variables selected for mutation

    %================================ Syntax ==================================
    %  [ofcn, best,exitflag_count] = MVMOS_SH(fitfcn,repcont,varargin) 
    %  Inputs:
    %  fitfcn   - Function handle for calculation of objective function and constraints
    %  repcont  - Actual repetition of the optimization
    %  varargin - Problem number
    %  Outputs:
    %  ofcn - Recorded objective function values in steps as defined by parameter.rec_step
    %  best - Values of optimization variables in the last iteration
    %  exitflag_count - Recorded flags identifying the reason for termination of local search algorithm
    %==========================================================================

    global parameter
    global printff sn 
       

    %%----------------- Create initial random population ------------------   
    xx=zeros(parameter.n_par,parameter.n_var);
    x_norm=xx;
    %Start initialization: x_normalized
    for iijj=1:parameter.n_par
        for jjkk=1:parameter.n_var
            xx(iijj,jjkk)=parameter.x_min (jjkk) + rand*(parameter.x_max(jjkk)-parameter.x_min(jjkk));
        end
        x_norm(iijj,:)=(xx(iijj,:)-parameter.x_min)./parameter.scaling;
    end% End initialization
    x_normalized=x_norm;

    %% ------------------ Intialize control parameters --------------------
    max_eval = parameter.MaxEval;
    rec_step = round(parameter.rec_step*max_eval);
    n_par = parameter.n_par; 
    n_var = parameter.n_var; 
    n_to_save = parameter.n_tosave; 
    n_randomly_ini = parameter.n_random_ini;
    n_randomly_last = parameter.n_random_last;
    Indep_run=parameter.Indep_run;
    mode = parameter.mode;
    fs_factor_start = parameter.fs_factor_start;
    fs_factor_end = parameter.fs_factor_end;
    dddd = ones(n_par,n_var)*parameter.dddd;
    delta_dddd_start = parameter.delta_dddd_start; 
    delta_dddd_end = parameter.delta_dddd_end; 
    nrand_method=parameter.nrand_method;
    
    %% ------------------- Data structure for the table -------------------
    table.bests = zeros(parameter.n_tosave,parameter.n_var,n_par);
    table.fitness = Inf*ones(parameter.n_tosave,1,n_par);
  
    %% --------------------------- Mapping --------------------------------
    shape = zeros(n_par,n_var);
    x_normalized_best = x_normalized;
    meann = x_normalized;
    meann_app = x_normalized;
    
    %% ---------------------- Variable selection --------------------------
    izm = zeros(1,n_par);
    izz = zeros(1,n_par);
    considered = true(n_par,n_var);
    variance =ones(n_par,n_var);
    probab=ones(n_par,n_var);
    values_noneq = zeros(n_to_save,1);

    %% ---------------------- Checking correctness ------------------------
    if (n_randomly_last<1)
        n_randomly_last=1;
    end
    
    
    if (n_randomly_last>n_var)
        n_randomly_last=n_var;
    end
    
    
    if (n_randomly_ini>n_var)
        n_randomly_ini=n_var;
    end  

    
    if (mode<1)
        mode=4d0;
    end

    
    if (mode>5)
        mode=4d0;
    end

    
    if (max_eval<=0)
        max_eval=100000d0;
    end


    if (fs_factor_start<=0)
        fs_factor_start=1d0;
    end

    
    if (fs_factor_end<=0)
        fs_factor_end=1d0;
    end

    fs_factor0=fs_factor_start;
 
    
    if (n_to_save<=1)
        n_to_save=2d0;
    end

    
    if (delta_dddd_start<=0)
        delta_dddd_start=0.2d0;
    end
    
    if (delta_dddd_end<=0)
        delta_dddd_end=0.2d0;
    end
    
    delta_dddd0=delta_dddd_start;
    delta_dddd1=1.d0+delta_dddd0;
    
    yes_fs_factor=true;
    if (fs_factor_start==fs_factor_end)
        yes_fs_factor=false;
    end
    
    yes_delta_dddd=true;
    if (delta_dddd_start==delta_dddd_end)
        yes_delta_dddd=false;
    end
  
    yes_n_randomly=true;
    if (n_randomly_ini==n_randomly_last)
        n_randomly=n_randomly_last;
        yes_n_randomly=false;
    end

    %% ----------------------------- Counters ---------------------------------
    fe_count1w=0;
    fe_count1=0;
    na_pg=n_par;
    ratio_gute_max=0.7; %Max percentage of good particles
    ratio_gute_min=0.2; %Min percentage of good particles
    no_in = zeros(1,n_par);
    no_inin = zeros(1,n_par);
    n_par_last=n_par;
    
    indpendent_run_p=zeros(1,n_par);
    local_search0=1.5d0/100d0/n_var; % probability of local search
    best_results=zeros(max_eval,1);
    goodbad=zeros(n_par,1);
    make_sense=max_eval-round(n_var*100.d0/2);

    counter_fmincon=0;
    counter_fmincon_FEVALS=0;

    l_vari=2; 
    if (l_vari<2)
        l_vari=2;
    end

    %% ----------------------------- MVMO-SH ------------------------------
    if sn
        fprintf('===============================================================================\n');
        fprintf('                   Mean-Variance Mapping Optimization Results                  \n');
        fprintf('===============================================================================\n');
        fprintf('Nomenclature:                                                                  \n');
        fprintf('FE-No.      => Objective function evaluation number                            \n');
        fprintf('NAP         => Number of particles                                             \n');
        fprintf('AGBP        => Actual global best particle                                     \n');
        fprintf('OF          => Global best objective function                                  \n');
        fprintf('Function    => Composition function being optimized                            \n');
        fprintf('Run         => Optimization repetition                                         \n');
        fprintf('No_fmincon  => Calls of local search                                           \n');
        fprintf('Ev_fmincon  => Number of function evaluations performed by local search        \n');
        fprintf('\n');
        fprintf('    FE-No.     NAP        AGBP            OF           Function        Run      No_fmincon   Ev_fmincon    \n');
        fprintf('    ------    ------   ---------      -----------     ----------     --------   ----------   ----------    \n');
    end
   
    delta_nrandomly=n_randomly_ini-n_randomly_last;
    tol_flag=0;
    A=zeros(n_par,1);   
    
    
    while (tol_flag==0) 
        
        ff=real(fe_count1/max_eval);
        ff2=ff*ff;
        one_minus_ff2=1.d0-ff2*0.99;
        shift=one_minus_ff2*0.5;
        
        %Determining the relative number of particles belonging to the group of
        %good particles
        border_gute0=ratio_gute_max-ff*(ratio_gute_max-ratio_gute_min);
        border_gute=round(n_par_last*border_gute0);

         
        %Selecting the subset of variables to be mutated
        if yes_n_randomly
            switch nrand_method
                case 1
                    n_randomly=round(n_randomly_ini-ff*delta_nrandomly);
                case 2
                    n_randomly=round(n_randomly_ini-ff2*delta_nrandomly); 
                case 3
                    n_randomly=round(n_randomly_last+(1.0-ff)*(1.0-ff)*delta_nrandomly); 
                case 4
                    n_randomly=round(unifrnd(n_randomly_last,n_randomly_ini)); 
                otherwise
                    if nrand_method==42
                        n_randomly_X=round(n_randomly_ini-ff2*delta_nrandomly); 
                    elseif nrand_method==43
                        n_randomly_X=round(n_randomly_last+(1.0-ff)*(1.0-ff)*delta_nrandomly); 
                    else
                        n_randomly_X=round(n_randomly_ini-ff*delta_nrandomly);
                    end
                    n_randomly=round(n_randomly_last+rand*(n_randomly_X-n_randomly_last));
            end
        end
        
        %Quadratic variation of fs_factor0
        if yes_fs_factor
            fs_factor0=fs_factor_start+ff2*(fs_factor_end-fs_factor_start); 
        end
        
        %Quadratic variation of delta_dddd0
        if yes_delta_dddd
            delta_dddd0=delta_dddd_start+ff2*(delta_dddd_end-delta_dddd_start); 
            delta_dddd1=1.d0+delta_dddd0;
        end

        %Evaluating the particles.....
        for ipp=1:parameter.n_par
            
            if rand < local_search0 &&  fe_count1 < make_sense &&  fe_count1 > 1    
                [msgstr, msgid] = lastwarn;
                TFrcond = strcmp('MATLAB:nearlySingularMatrix',msgid);
                if TFrcond~=0
                    rcond_value0=str2num(msgstr(81:end-1));
                end
                
                [xt.fitness,~,x_normalized(ipp,:),FEVALS,exitflag] = LocalSearchMVMOSH(x_normalized(ipp,:),varargin{:}); %Local search
                
                [msgstr1, msgid1] = lastwarn;
                TFrcond1 = strcmp('MATLAB:nearlySingularMatrix',msgid1);
                if TFrcond1~=0
                    rcond_value=str2num(msgstr1(81:end-1));
                    if (exist('rcond_value0','var')==1) && (rcond_value0 ~= rcond_value) 
                        local_search0=0;
                    end
                end
                 
                
                counter_fmincon=counter_fmincon+1; %Only for printing
                exitflag_count(counter_fmincon,1)=exitflag;
                exitflag_count(counter_fmincon,2)=fe_count1;
                counter_fmincon_FEVALS=counter_fmincon_FEVALS+FEVALS;  %Only for printing
                
                for iq=fe_count1+1:fe_count1+FEVALS-1
                   if iq <= max_eval
                       best_results(iq)=best_results(iq-1);
                   else
                       break
                   end
                end
                
                fe_count1=fe_count1+FEVALS;
                if fe_count1 <= max_eval
                   if fe_count1 >= 2
                       if xt.fitness < best_results(fe_count1-1)
                           best_results(fe_count1)=xt.fitness;
                           ipp_gbest=ipp;
                       else
                              best_results(fe_count1)=best_results(fe_count1-1);
                       end
                   else
                          best_results(fe_count1)=xt.fitness;
                          ipp_gbest=ipp;
                   end
                end
            else
                [xt.fitness,~,x_normalized(ipp,:)] = feval(fhd,x_normalized(ipp,:),varargin{:}); %Evaluation of fitness
                fe_count1=fe_count1+1;
                if fe_count1 <= max_eval
                    if fe_count1 >= 2
                        if xt.fitness < best_results(fe_count1-1)
                            best_results(fe_count1)=xt.fitness;
                            ipp_gbest=ipp;
                        else
                            best_results(fe_count1)=best_results(fe_count1-1);
                        end
                    else
                        best_results(fe_count1)=xt.fitness;
                        ipp_gbest=ipp;
                    end
                end
            end
            
            
            if sn %Display optimization progress in command window
                if (fe_count1 == 1) 
                    fprintf('%8d    %5d     %5d      %17.7E     %5d        %5d         %5d         %5d\n',...
                        fe_count1,na_pg,ipp_gbest,best_results(fe_count1),varargin{:},repcont,counter_fmincon,counter_fmincon_FEVALS); 
                elseif (mod(fe_count1,printff) == 0)
                    fec_prev=fe_count1;
                    fprintf('%8d    %5d     %5d      %17.7E     %5d        %5d         %5d         %5d\n',...
                        fe_count1,na_pg,ipp_gbest,best_results(fe_count1),varargin{:},repcont,counter_fmincon,counter_fmincon_FEVALS); 
                elseif (exist('fec_prev','var') && (fe_count1>(fec_prev+printff)))
                    fec_prev=fec_prev+printff;
                    fprintf('%8d    %5d     %5d      %17.7E     %5d        %5d         %5d         %5d\n',...
                        fec_prev,na_pg,ipp_gbest,best_results(fec_prev),varargin{:},repcont,counter_fmincon,counter_fmincon_FEVALS); 
                end
            end
                         
            % Store the n-best solution corresponding to the corresponding particle's archive
            Fill_solution_archive();
            meann_app(ipp,:)= meann(ipp,:);
            
            
            if (na_pg==1) %Only one particle
                x_normalized(ipp,:)=x_normalized_best(ipp,:);
                goodbad(1,1)=1;
            
            else %Several particles
                indpendent_run_p(ipp)=indpendent_run_p(ipp)+1;
                if (indpendent_run_p(ipp)>= Indep_run )  %Non-independent evaluation of particles             
                    if fe_count1w<1 
                        fe_count1w=fe_count1;
                    end
                    
                    %Determining the proportion of good particles
                    A(1:n_par)=table.fitness(1,:,1:n_par);
                    [~,IX] = sort(A);
                                        
                    goodbad(IX(border_gute+1:n_par),1)=0;
                    goodbad(IX(1:border_gute),1)=1;
                    iec=randi(border_gute-2,1,1);                                      

                    onep=IX(iec+1); %First (global best) particle of the group of good particles
                    bestp=IX(1); %Randomly selected intermediate particle of the group of good particles
                    worstp=IX(border_gute); %Last particle of the group of good particles
                    
                    %Multi-parent strategy for bad particles
                    if ~goodbad(ipp)   
                        beta1 = 2.0*(rand - shift);
                        for jl=1:n_var
                            x_normalized(ipp,jl) =x_normalized_best(onep,jl)+beta1*(x_normalized_best(bestp,jl)-x_normalized_best(worstp,jl));
                            while x_normalized(ipp,jl) > 1.0d0 ||  x_normalized(ipp,jl)<0.0d0  
                                beta2 = 2.0*(rand - shift);  
                                x_normalized(ipp,jl) =x_normalized_best(onep,jl)+beta2*(x_normalized_best(bestp,jl)-x_normalized_best(worstp,jl));
                            end
                        end
                        meann_app(ipp,1:n_var) =x_normalized(ipp,1:n_var); %Update the mean values for all variables of the ipp particle
                    else
                        x_normalized(ipp,:)= x_normalized_best(ipp,:); %Local best-based parent assignment for good particles
                    end
                else
                    x_normalized(ipp,:)=x_normalized_best(ipp,:); %Local best-based parent assignment during independent evaluations
                end
            end
            
            %Change the corresponding variable(s)
            if mode==5 %Roulette tournament
                probab(ipp,:) =1.d0./(dddd(ipp,:));
            end
            considered(ipp,1:n_var) = false;
            
            
            VariableSelect1(); % Call random variable selection strategy
           
            %Generation of random input for the mapping function
            for jl=1:n_var
                if considered(ipp,jl) 
                    x_normalized(ipp,jl) = rand();
                end
            end
            
            
            %Applying the mapping function for seleced variables
            for ivar=1:n_var
                if  ((considered(ipp,ivar))&&(shape(ipp,ivar)>1.d-50))
                    sss1 = shape(ipp,ivar);
                    sss2 = sss1; 
                    delta_ddd_x=delta_dddd0*(rand()-0.5d0)*2.0d0+delta_dddd1; 
                    if (shape(ipp,ivar) > dddd(ipp,ivar))
                        dddd(ipp,ivar) = dddd(ipp,ivar)*delta_ddd_x;
                    else
                        dddd(ipp,ivar) = dddd(ipp,ivar)/delta_ddd_x;
                    end
                    
                    isteur = randi(2,1)-1;
                    if isteur %Random assignment of shape
                        sss1=dddd(ipp,ivar) ;
                    else
                        sss2=dddd(ipp,ivar);  
                    end
                    
                    fs_factor=fs_factor0*(1d0+rand);
                    sss1=sss1*fs_factor;
                    sss2=sss2*fs_factor;
                       
                    x_normalized(ipp,ivar) = ...
                        h_function(meann_app(ipp,ivar),sss1,sss2,x_normalized(ipp,ivar)); %Mapping function
                
                end
            end                                     
           
            if (fe_count1>=max_eval)
                tol_flag=1;
                break;
            end 
            
        end %End n_par loop
 
    end %End while loop
       
    
    ofcn=best_results(rec_step);
%     ofcn(ofcn<=1e-8)=0;
    
    best=parameter.x_min+(parameter.x_max-parameter.x_min).*table.bests(1,:,ipp_gbest);
    
    
    
    %% ----------------------- Complementary functions ------------------------
        function Fill_solution_archive()
        no_in(ipp) = no_in(ipp)+1;
        changed = false;

        if no_in(ipp) ==1 % the solution coming to the table for the first time
            table.bests(1:n_to_save,:,ipp) = repmat(x_normalized(ipp,:),n_to_save,1);
            table.fitness(1:n_to_save,:,ipp) = repmat(xt.fitness,n_to_save,1);

            x_normalized_best(ipp,:) = table.bests(1,:,ipp); % set the best solution to the one of the first rank
            no_inin(ipp)=no_inin(ipp)+1;
            

        else % not for the first time and check for the update
           i_position =0;
           % check if the new coming solution is less than any in the table
           if (xt.fitness<table.fitness(n_to_save,:,ipp))
               for i=1:n_to_save 
                   if (xt.fitness<table.fitness(i,:,ipp))                                  
                       i_position = i;
                       changed =true;
                       if (i<n_to_save)
                           no_inin(ipp) = no_inin(ipp)+1; % how many times good solutions were found   
                       end
                       break;
                   end
               end
           end
        end

        if changed   % if the new individual is better than any archived individual.
                     % Move the individuals and corresponding fitness values
                     % downward so that the individuals are sorted based on the
                     % fitness value in a descending order      

            nnnnnn = n_to_save;
            if (no_inin(ipp) < n_to_save); nnnnnn = no_inin(ipp); end
            isdx=nnnnnn:-1:i_position+1;
            table.bests(isdx,:,ipp) = table.bests(isdx-1,:,ipp);
            table.fitness(isdx,:,ipp)= table.fitness(isdx-1,:,ipp);

            % save the new best
            table.bests(i_position,:,ipp) = x_normalized(ipp,:);
            table.fitness(i_position,:,ipp) = xt.fitness;

            % calculation of mean and variance
            if ((no_inin(ipp)>=l_vari))
                for ivvar = 1:n_var
                    [meann(ipp,ivvar),variance(ipp,ivvar)] = mv_noneq(nnnnnn,table.bests(1:nnnnnn,ivvar,ipp));
                 end
                id_nonzero = (variance(ipp,:) > 1.1d-100);
                shape(ipp,id_nonzero) = -log(variance(ipp,id_nonzero));
            end

        end
            x_normalized_best(ipp,:) = table.bests(1,:,ipp);   
        end

        function VariableSelect1()
            
          switch mode
            case 1
                for ii=1:n_randomly
                    isrepeat = false;
                    while ~isrepeat
                        inn=round(rand*(n_var-1))+1;
                        if (~considered(ipp,inn))
                            isrepeat = true;
                        end
                    end
                    considered(ipp,inn)=true;
                end
            case 2
                in_randomly=0;
                isrepeat = false;
                izz(ipp)=round(rand*(n_var-1))+1; 
                while ~isrepeat
                    in_randomly=in_randomly+1;
                    if (izz(ipp)< 1) 
                        izz(ipp)=n_var;
                    end
                    considered(ipp,izz(ipp))=true;
                    izz(ipp)=izz(ipp)-1;
                    if (~(in_randomly<n_randomly)) 
                        isrepeat = true;
                    end
                end
            case 3
                in_randomly=0;
                izm(ipp)=izm(ipp)-1;
                if (izm(ipp)< 1) 
                    izm(ipp)=n_var;
                end
                izz(ipp)=izm(ipp);
                isrepeat = false;
                while ~isrepeat
                    in_randomly=in_randomly+1;
                    if (izz(ipp)< 1) 
                         izz(ipp)=n_var;
                    end
                    considered(ipp,izz(ipp))=true;
                    izz(ipp)=izz(ipp)-1;
                    if (~(in_randomly<n_randomly)) 
                        isrepeat = true;
                    end
                end   
            case 4
                izm(ipp)=izm(ipp)-1;
                if (izm(ipp)< 1) 
                    izm(ipp)=n_var;
                end
                considered(ipp,izm(ipp))=true;
                if (n_randomly>1)  
                    for ii=1:n_randomly-1
                        isrepeat = false;
                        while ~isrepeat
                            inn=round(rand*(n_var-1))+1;
                            if (~considered(ipp,inn))
                                isrepeat = true;
                            end
                        end
                        considered(ipp,inn)=true;
                    end
                end
            case 5
                  summep=sum(probab(ipp,:));
                  wahr=probab(ipp,:)/summep;
                  SS0=0.d0;
                  SS=zeros(1,n_var);
                  for imm=1:(n_var-1)
                      SS0=SS0+wahr(imm);
                      SS(imm+1)=SS0;
                  end
                  for ijlr=2:n_var
                      wahr(ijlr)=wahr(ijlr)+SS(ijlr);
                  end 
                  for ltt=1:n_randomly
                       isrepeat = false;
                       while  ~isrepeat
                        rnn=rand;
                        for irw=1:n_var
                          if considered(ipp,irw)
                           continue
                          end
                          if (irw==1)
                              unten=0.d0;
                          else
                              unten=wahr(irw-1);
                          end
                         if (rnn>=unten)&&(rnn<wahr(irw))
                              isrepeat = true;
                             considered(ipp,irw)=true;
                             break;
                          end
                        end
                       end
                  end
          end
        end
    

        function [vmean,vvariance] = mv_noneq(n_to_save,values)
            iz =1; 
            values_noneq(iz)=values(1);
            for ii_jj=2:n_to_save
                izz = iz;
                gleich = false;
                for kk_ii=1:izz
                    if  abs(values_noneq(kk_ii) - values(ii_jj)) <  1.d-70 ; 
                        gleich = true;
                        break;
                    end
                end
                if ~gleich;
                    iz = iz+1;
                    values_noneq(iz)=values(ii_jj);
                end
            end
             vmean = values_noneq(1);
            if (iz>1)
               for kk_ii=2:iz
                    vmean = vmean+values_noneq(kk_ii);
               end
               
               vmean = vmean/iz;
           end
           vvariance = 0.d0;
           if (iz>1)
                for kk_ii=1:iz
                    vvariance =vvariance+(values_noneq(kk_ii)-vmean)*(values_noneq(kk_ii)-vmean);
                end
                  vvariance = vvariance/iz;
           else
                  vvariance=1.0d-100 ;
            end
        end
    
     %% Mapping h-function
     function x = h_function(x_bar,s1,s2,x_p)
         H0= (1.0d0-x_bar)*exp(-s2);
         x=(x_bar-x_bar/exp(x_p*s1))+(1.d0-x_bar)/exp(s2-x_p*s2)+ (x_bar/exp(s1)+H0)*x_p-H0 ;           
     end
 
 
    end