function [f,g,xn_out] = test_func_all_cec2013(xx_yy1,func_num)

global parameter 
global obj_func_ref

fhd=str2func('cec13_func');

%Denormalize to the original [min, max] range 
xx_yy = parameter.x_min+parameter.scaling.* xx_yy1;


f1 = feval(fhd,xx_yy',func_num)-obj_func_ref(func_num);


f=f1; %Value of the objective function
g=0; %Constraints

% Normalize again to [0, 1]
xn_out = (xx_yy-parameter.x_min)./parameter.scaling;

end