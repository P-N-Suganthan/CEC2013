function Adapter()

global settings;
 global mystat;
    dim = mystat.D;
    MAX_EVAL = myeval(settings.MaxEvals);
     
        irest = 0;
        settings.iglobalrun = 0;
        global mystat;
      %  while (fgeneric('evaluations') < MAX_EVAL) (fgeneric('fbest') - fgeneric('ftarget') >= 0)
        while (mystat.nevals < MAX_EVAL) && (mystat.Fbest > 1e-9)%
            settings.iglobalrun  = settings.iglobalrun + 1;
            maxeval_available = MAX_EVAL - mystat.nevals;%fgeneric('evaluations');
            %%%%%%  Run x-ACM
            xacmes('MyFunc',dim,maxeval_available);
            %%%%%%
            irest = irest + 1;
       %     ff = fgeneric('fbest') - fgeneric('ftarget');
        end;
        if (irest > 1)
            disp( [' nrestart:' num2str(irest) ] );
        end;





