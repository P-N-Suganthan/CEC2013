function Fit = MyFunc(x)
global settings;

%Fit = feval('fgeneric',x) - settings.ftarget;    % does not change the results, but better for logs
%disp(x);

global mystat;
fhd=str2func('cec13_func');
Fit = feval(fhd,x,mystat.func_num)- mystat.func_target;
npt = size(Fit,2);

for i=1:npt
    mystat.nevals = mystat.nevals + 1;
    if (Fit(i) * 0 ~= 0)
        mystat.stop = 1;
    else
        if (Fit(i) < mystat.Fbest)
            mystat.Fbest = Fit(i);
        end;
    end;
%    if ((mystat.nevals == 100*mystat.D) || (mystat.nevals == 200*mystat.D) || (mystat.nevals == 300*mystat.D)|| (mystat.nevals == 400*mystat.D) ...
%        || (mystat.nevals == 500*mystat.D)|| (mystat.nevals == 600*mystat.D)|| (mystat.nevals == 700*mystat.D)|| (mystat.nevals == 800*mystat.D) ...
%        || (mystat.nevals == 900*mystat.D)|| (mystat.nevals == 1000*mystat.D))
    if ((rem(mystat.nevals,100) == 0) || (Fit(i) == 0)) 
        fprintf(mystat.file, [num2str(mystat.nevals) '\t' num2str(mystat.Fbest) '\t' num2str(Fit(i)) '\n']);
    end;
end;
