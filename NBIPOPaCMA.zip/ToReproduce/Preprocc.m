close all;
dir0 = 'IPOPCMA_10D';
dim = 30;
nproblems = 28;
ndims = 3;
regime = 4;
endmed = 0;

ntargets = 100;
powMin = -1;
powMax = 4;
for i=1:ntargets
    targets(i) = 10^( powMax - (powMax - powMin)*(i/ntargets));
end;

nalgo = 8;
algoranks_sum = 1;
for kkoef=1%[0.1,0.5,1.0]%[0.01,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]
for idim=1:ndims
    if (idim == 1)  dim = 10;   end;
    if (idim == 2)  dim = 30;   end;
    if (idim == 3)  dim = 50;   end;
    len = (10000*dim)/100;
    nruns = 51;
    for ialgo=1:nalgo
        if (ialgo == 1) algoname = 'IPOPCMA';   end;
        if (ialgo == 2) algoname = 'NIPOPCMA';   end;
        if (ialgo == 3) algoname = 'BIPOPCMA';   end;
        if (ialgo == 4) algoname = 'NBIPOPCMA';   end;
        if (ialgo == 5) algoname = 'IPOPaCMA';  color = 'blue';   end;
        if (ialgo == 6) algoname = 'NIPOPaCMA'; color = 'black';    end;
        if (ialgo == 7) algoname = 'BIPOPaCMA'; color = 'red';    end;
        if (ialgo == 8) algoname = 'NBIPOPaCMA'; color = 'magenta';    end;
        dir0 = [algoname '_' num2str(dim) 'D'];
    %    algoname = ialgo;
        resfilename = [dir0 '\\' 'algo' num2str(ialgo) '_dim' num2str(dim) '.res'];
        resfile = fopen(resfilename,'w');
                
        for iproblem=1:nproblems%1:28
            disp([num2str(ialgo) ' ' num2str(iproblem)]);
            fbestvals = 5*ones(nruns,len);
            if (regime == 0)
                for irun=1:nruns
                    filename = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '_' num2str(irun) '.txt'];

                    [ieval fbest fcur] =  textread(filename,'%f %f %f ','headerlines',0);
                    sz = size(fbest,1);
                    if (sz > len)   sz = len;   end;
                    fbestvals(irun,1:sz) = fbest(1:sz);
                end;
                med = median(fbestvals(:,:));
                 
                medfilename = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '.ainds'];
                medfile = fopen(medfilename,'w');
                for il=1:len
                    fprintf(medfile, '%f\t%f\n', il*100, med(il));
                end;
                fclose(medfile);
            end;
            if (regime == 1)
                medfilename = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '.ainds'];
                [ieval med] =  textread(medfilename,'%f %f ','headerlines',0);
                
            end;
            if (regime == 2)
                for irun=1:nruns
                    filename = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '_' num2str(irun) '.txt'];

                    [ieval fbest fcur] =  textread(filename,'%f %f %f ','headerlines',0);
                    sz = size(fbest,1);
                  %  if (sz > len)   sz = len;   end;
                    fbest(sz:len) = fbest(sz);
                    fbestvals(irun,1:len) = fbest(1:len);
                end;
                med = median(fbestvals(:,:));
                 
                
                for il=1:len
                    bestval = min( fbestvals(:,il) );
                    worstval = max( fbestvals(:,il) );
                    medval = median( fbestvals(:,il) );
                    meanval = mean( fbestvals(:,il) );
                    stdval = std( fbestvals(:,il) );
                end;
                fbestvals(:,il)
                fprintf(resfile, '%d & %5.3f & %5.3f & %5.3f & %5.3f & %5.3f \\\\ \\hline \n', iproblem, bestval, worstval, medval, meanval, stdval);
                
            end;
            if (regime == 4)
                alltargets = 0;
                ialltargets = 0;
                alltargets_evals = 0;
                for irun=1:nruns
                    filename = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '_' num2str(irun) '.txt'];

                    [ieval fbest fcur] =  textread(filename,'%f %f %f ','headerlines',0);
                    sz = size(fbest,1);
                    
                    ipos = 1;
                    npos = sz;
                    itarget = 1;
                    cdfvals = 0;
                    cdfcur = 0;
                    solvedtargets = 0;
                   while (ipos <= npos) && (itarget <= ntargets)
                    if ((fbest(ipos) < targets(itarget)) && (ieval(ipos) <= len*100))
                        cdfcur = cdfcur + 1/ntargets;
                        cdfvals(itarget) = cdfcur;
                        itarget = itarget + 1;
                        solvedtargets = solvedtargets + 1;
                        
                        ialltargets = ialltargets + 1;
                        alltargets_evals(ialltargets) = ieval(ipos);
                    else
                        ipos = ipos + 1;
                    end;
                   end;
                   
                    
                    if (sz > len)   sz = len;   end;
                    fbestvals(irun,1:sz) = fbest(1:sz);
                end;
                [alltargets_evals_sort indx] = sort( alltargets_evals );
                
                ii = 1:size(indx,2);
                ii_vals = ii / (nruns * ntargets);
                ecdfnameAggregated = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '.aecdf'];
                ecdffileAggregated = fopen(ecdfnameAggregated,'w');

                npt = size(indx,2);
                for i=1:npt
                     fprintf(ecdffileAggregated, '%f %f\n', alltargets_evals_sort(i), ii_vals(i));
                end;
                if (npt < len*nruns)
                    alltargets_evals_sort(npt+1) = len*100;
                    ii_vals(npt+1) = ii_vals(npt);
                    fprintf(ecdffileAggregated, '%f %f\n', alltargets_evals_sort(npt+1), ii_vals(npt+1));
                    ii = 1:(size(indx,2)+1);
                end;
             %   plot(alltargets_evals_sort(ii), ii_vals);    hold on;
               
                fclose(ecdffileAggregated);
            end;
          %  endmed(ialgo,iproblem + nproblems*(idim-1)) = med(end);
        %    imed = (len)*kkoef-1;
        %    endmed(ialgo,iproblem + nproblems*(idim-1)) = med(imed);
        end;
        fclose(resfile);
      %  color = 'blue';
      %  if (ialgo > 4)  color = 'red';  end;
    %    semilogy((1:len)*100, med, 'color', color);   hold on;
    end;
end;

algoranks = zeros(1,nalgo);

for idim=1:ndims
for iproblem=1:nproblems
    if (idim == 1)  dim = 10;   end;
    if (idim == 2)  dim = 30;   end;
    if (idim == 3)  dim = 50;   end;
    sols = endmed(:,iproblem + nproblems*(idim-1));
    [minval iminval] = min( sols );
    len = (10000*dim)/100;
  %  for iimed = [0.01*len, 0.1*len, 0.2*len, 0.3*len, 0.4*len, 0.5*len, 0.6*len, 0.7*len, 0.8*len, 0.9*len, 1*len]
      %  if (iimed == len)   medi(ialgo,iproblem + nproblems*(idim-1)) = med(end);   
      %  else                medi(ialgo,iproblem + nproblems*(idim-1)) = med(iimed);     end;
        for ialgo=1:nalgo
            if (endmed(ialgo,iproblem + nproblems*(idim-1)) == minval)
                algoranks(ialgo) = algoranks(ialgo) + 1;
            end;
        end;
  %  end;
%    if (minval ~= 0)
%        algoranks(iminval) = algoranks(iminval) + 1;
%    end;
    zz = 0;
end;    
end;
    if (algoranks_sum == 0) algoranks_sum = algoranks;
    else                    algoranks_sum = algoranks_sum + algoranks;  end;
end;
zz = 0;

