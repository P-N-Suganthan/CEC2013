function cec2013()
global mystat; global zzz;

global settings;
dir = 'BIPOPaCMA';

dir = '';
if (settings.newRestartRules == 1)  dir = [dir 'N'];    end;
if (settings.BIPOP == 1)            dir = [dir 'BIPOP'];    end;
if (settings.BIPOP == 0)            dir = [dir 'IPOP'];     end;   
if (settings.CMAactive == 1)        dir = [dir 'a'];        end;
dir = [dir 'CMA'];

for dim=settings.dims
    
curdir = [dir '_' num2str(dim) 'D'];
mkdir(curdir);
zzz = 0;
mystat = 0;

func_num=1;
Xmin=-100;
Xmax=100;
pop_size=100;
iter_max=1000;
runs=11;
fhd=str2func('cec13_func');
fhd=str2func('MyFunc');
mystat.gfile = fopen([curdir '/' num2str(dim) '.txt'],'w');
for i=settings.funs
    func_num=i;
    mystat.func_num = func_num;
    for j=settings.instances%1:runs
        rand('state',sum((100+j)*clock));
        mystat.run_num = func_num;
        mystat.D = dim;
        mystat.Fbest = 1e+30;
        mystat.nevals = 0;
        mystat.iinst = j;
        mystat.file = fopen([curdir '/' num2str(i) '_' num2str(dim) '_' num2str(j) '.txt'],'w');
        func_target = -1500 + i*100;
        if (i >= 15)  func_target = func_target + 100;  end; 
        mystat.func_target = func_target;
        
       % i,j,
       % [gbest,gbestval,FES]= PSO_func(fhd,D,pop_size,iter_max,Xmin,Xmax,func_num);
        Adapter();
         
      %  xbest(j,:)=gbest-func_target;
        fbest(i,j)=mystat.Fbest;
      %  fbest(i,j)
        
        fclose(mystat.file);
    end
    f_mean(i)=mean(fbest(i,:));
    
    fprintf(mystat.gfile, [num2str(f_mean(i)) '\n']);
end
fclose(mystat.gfile);

end;