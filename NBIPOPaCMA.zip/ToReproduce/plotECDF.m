close all;
dir0 = 'IPOPCMA_10D';

nproblems = 28;
ndims = 3;
ntargets = 100;
nalgo = 8;

close all;

hax = axes('Position', [.15, .15, .8, .75]); 

plotALLcdf = 1;
for iplotALL=[1,2,3]%1:2
    algos = [1,3,5,6,7,8];
 %   if (plotALLcdf == 1)    algos = 1;  end;
for igl=algos%[1,2]
for iproblem=1:nproblems%1:28
    if (plotALLcdf == 0)
        close all;
        hax = axes('Position', [.15, .15, .8, .75]); 
    end;
    legloc = 'NorthWest';
    powminx = 2;
    miny = 0;   maxy = 1;
    if ((iproblem == 1)|| (iproblem == 5) || (iproblem == 10))  legloc = 'SouthEast';  powminx = 1;  end;
    if ((iproblem == 4) || (iproblem == 6))   legloc = 'SouthEast'; end;
    if (iproblem == 9)  miny = 0.4;   maxy = 0.8;   end;
    if (iproblem == 11)  miny = 0.4;   maxy = 0.9;   end;
    if (iproblem == 12)  miny = 0.4;   maxy = 1;   end;
    if (iproblem == 13)  miny = 0.3;   maxy = 1;   end;
    if (iproblem == 14)  miny = 0.0;   maxy = 0.4;   end;
    if (iproblem == 15)  miny = 0.0;   maxy = 0.4;   end;
    if (iproblem == 16)  miny = 0.6;   maxy = 1;   end;
    if (iproblem == 17)  miny = 0.3;   maxy = 0.6;   end;
    if (iproblem == 18)  miny = 0.3;   maxy = 0.5;   end;
    if (iproblem == 19)  miny = 0.5;   maxy = 0.8;   end;
    if (iproblem == 20)  miny = 0.57;   maxy = 0.61;   end;
    if (iproblem == 21)  miny = 0.2;   maxy = 0.4;   end;
    if (iproblem == 22)  miny = 0.;   maxy = 0.3;   end;
    if (iproblem == 23)  miny = 0.;   maxy = 0.3;   end;
    if (iproblem == 24)  miny = 0.2;   maxy = 0.4;   end;
    if (iproblem == 25)  miny = 0.2;   maxy = 0.4;   end;
    if (iproblem == 26)  miny = 0.2;   maxy = 0.4;   end;
    if (iproblem == 27)  miny = 0.1;   maxy = 0.3;   end;
    if (iproblem == 28)  miny = 0.2;   maxy = 0.3;  legloc = 'SouthEast';  end;

    
iplots = [1,2,3];
if (plotALLcdf == 1)    iplots = 1; end;
for iplot=iplots%1:2   
    
    
    if (plotALLcdf == 1)    algos = igl;    end;
    for ialgo=algos%1:nalgo
        
        if (ialgo == 1) algoname = 'IPOPCMA';   myleg ='IPOP-CMA';   leg{1} = myleg; color = 'red';      marker = 'o';  end;
        if (ialgo == 2) algoname = 'NIPOPCMA';  myleg ='NIPOP-CMA'; color = 'yellow';    marker = 'p';   end;
        if (ialgo == 3) algoname = 'BIPOPCMA';  myleg ='BIPOP-CMA';  leg{2} = myleg; color = 'green';    marker = 'd';    end;
        if (ialgo == 4) algoname = 'NBIPOPCMA'; myleg ='NBIPOP-CMA'; color = 'magenta';    marker = 'x';     end;
        if (ialgo == 5) algoname = 'IPOPaCMA';  myleg ='IPOP-aCMA';  leg{3} = myleg; color = 'blue';     marker = 'o';  end;
        if (ialgo == 6) algoname = 'NIPOPaCMA'; myleg ='NIPOP-aCMA'; leg{4} = myleg; color = 'black';    marker = 'd';  end;
        if (ialgo == 7) algoname = 'BIPOPaCMA'; myleg ='BIPOP-aCMA'; leg{5} = myleg; color = 'cyan';     marker = 'x';  end;
        if (ialgo == 8) algoname = 'NBIPOPaCMA'; myleg ='NBIPOP-aCMA'; leg{6} = myleg; color = 'magenta';  marker = 's';  end;
     
        
        
        marker_sav = marker;
        ievalssum = 0;
        ecdmax = 0;
        for idim=1:ndims
            if (idim == 1)  dim = 10;   end;
            if (idim == 2)  dim = 30;   end;
            if (idim == 3)  dim = 50;   end;
            len = (10000*dim)/100;
        
        dir0 = [algoname '_' num2str(dim) 'D'];
    %    algoname = ialgo;
            ecdfnameAggregated = [dir0 '\\' num2str(iproblem) '_' num2str(dim) '.aecdf'];
            
            [ieval cdf] =  textread(ecdfnameAggregated,'%f %f','headerlines',0);
            ieval = ieval / dim;
            
            if (idim == 1)  ievalssum = ieval;  ecdmax = cdf(end);
            else            ievalssum = [ievalssum; ieval]; ecdmax = ecdmax + cdf(end);     end;
       end;    
       
       [ievalssum_sort inxx] = sort(ievalssum);
       sz = size(inxx,1);
       cdf = ((1:sz)/(sz)) * (ecdmax/ndims);
       ieval = ievalssum_sort;
       
       if (iplot == 1)
           if (iproblem == 1)   ievalALL = ieval;   cdfALL  = ecdmax/ndims;
           else                 ievalALL = [ievalALL; ieval];  cdfALL = cdfALL + ecdmax/ndims; end;
       end;
      
       
            ii = 1:size(ieval,1);
            
            mymarker = '-';
            if (iplot == 1)  marker = ['-' marker]; ii = 1;   end;
            if (iplot == 2)  marker = mymarker;   end;
            %else            ii = [1000,10000,20000];    end;

            if (iplot == 3)
                iinew = 0;
                setofcand = [20,50,100,500,1000,5000,10000];
             %   setofcand = setofcand * dim;
             %   setofcand = [0.5,1,2,5,10,15,20,50, 100];
                for icand=1:size(setofcand,2)
                    j = 1;
                    cand = setofcand(icand);
                    [minval minind] = min( abs(ieval(ii) - cand) );
                    if (icand == 1) iinew = minind;
                    else            iinew = [iinew; minind];    end;  
                end;
                ii = iinew;    
            end;

           
            mksize = 10;
            if (plotALLcdf == 0)
                 semilogx(ieval(ii), cdf(ii), marker, 'MarkerSize', mksize, 'color', color);    hold on;
            end;
        end;
end;

if (plotALLcdf == 0)
    SetStyle(); 
    
    savname = ['f' num2str(iproblem)];
    axis([10^powminx 10^4 miny maxy]);
    fontsz = 16;
    titlestr = ['F' num2str(iproblem) ' in 10-D, 30-D and 50-D'];
    xlabeltext = '\# evaluations / dimension';
    ylabeltext = {'Proportion of function-target pairs'};
   	title(titlestr,'Interpreter', 'Latex','fontsize',fontsz);
     xlabel(xlabeltext,'Interpreter', 'Latex','fontsize',fontsz);
     ylabel(ylabeltext, 'Interpreter', 'Latex','fontsize',14);
  %  l = legend(leg{1},leg{2},leg{3},leg{4},leg{5},leg{6},leg{7},leg{8},'Location',legloc);
    l = legend(leg{1},leg{2},leg{3},leg{4},leg{5},leg{6},'Location',legloc);
    set(l,'interpreter','latex');
   % figure('units','normalized','outerposition',[0 0 1 1]);
   hFig = figure(1);
      x = 400;    y = 100;
        width = 450;    height = 400;
       set(hFig, 'Position', [x y width height]);


       filename = [savname '.eps'];
      saveas(hFig,filename,'psc2');
      
end;

end;

if (plotALLcdf == 1)

    [ievalALL_sort inxx] = sort(ievalALL);
    sz = size(inxx,1);
    cdf = ((1:sz)/(sz)) * (cdfALL/nproblems);
    ieval = ievalALL_sort;


    ii = 1:size(ieval,1);
    
    marker = marker_sav;
    
    mymarker = '-';
            if (iplotALL == 1)  marker = ['-' marker]; ii = 1;   end;
            if (iplotALL == 2)  marker = mymarker;   end;
            %else            ii = [1000,10000,20000];    end;

            if (iplotALL == 3)
                iinew = 0;
                setofcand = [25,50,100,250,500,1000,2500,5000,10000];
             %   setofcand = setofcand * dim;
             %   setofcand = [0.5,1,2,5,10,15,20,50, 100];
                for icand=1:size(setofcand,2)
                    j = 1;
                    cand = setofcand(icand);
                    [minval minind] = min( abs(ieval(ii) - cand) );
                    if (icand == 1) iinew = minind;
                    else            iinew = [iinew; minind];    end;  
                end;
                ii = iinew;    
            end;
              
    semilogx(ieval(ii), cdf(ii), marker, 'MarkerSize', mksize, 'color', color);    hold on;
end;    
    

end;

end;


if (plotALLcdf == 1)
    legloc = 'SouthEast';
    SetStyle(); 
     axis([10^1 10^4 0 1]); savname = 'all1';
    % axis([10^3 10^4 0.5 0.64]);   savname = 'allZoom';
    fontsz = 16;
    titlestr = 'All 28 functions in 10-D, 30-D and 50-D';
    xlabeltext = '\# evaluations / dimension';
    ylabeltext = {'\space \space \space \space \space          Proportion of function-target pairs'};
   	title(titlestr,'Interpreter', 'Latex','fontsize',fontsz);
     xlabel(xlabeltext,'Interpreter', 'Latex','fontsize',fontsz);
     ylabel(ylabeltext, 'Interpreter', 'Latex','fontsize',14);
  %  l = legend(leg{1},leg{2},leg{3},leg{4},leg{5},leg{6},leg{7},leg{8},'Location',legloc);
    l = legend(leg{1},leg{2},leg{3},leg{4},leg{5},leg{6},'Location',legloc);
    set(l,'interpreter','latex');
   % figure('units','normalized','outerposition',[0 0 1 1]);
 % set(gca,'OuterPosition',[121 121 121 121])
   
    hFig = figure(1);
      x = 400;    y = 100;
        width = 450;    height = 400;
       set(hFig, 'Position', [x y width height]);

       filename = [savname '.eps'];
      saveas(hFig,filename,'psc2');
end;
zz = 0;

