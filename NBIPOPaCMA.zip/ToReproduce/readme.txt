1. compile cec13_func.cpp using mex compiler as suggested in cec13_func.cpp
2. run all exp files (exp1.m, exp2., ..., exp51.m) one by one or on several cpu's to reproduce the results published in (Ilya Loshchilov, "CMA-ES with Restarts for Solving CEC 2013
Benchmark Problems" CEC2013)
Ilya Loshchilov, 19.06.2013, ilya.loshchilov@gmail.com