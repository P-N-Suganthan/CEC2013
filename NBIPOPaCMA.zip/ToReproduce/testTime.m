global settings;

settings.instances = [1:1];%[1:50];
settings.dims = [10,30,50];
settings.funs = [1:2];%[1,7,8,10,11,12,13,14];
settings.pathname = 'd1';
settings.algname = '';
settings.ntarray = [1];
settings.savfile = 'r1';

settings.BIPOP = 1; 
settings.newRestartRules = 0; 
settings.noisy = 0;
settings.CMAactive = 1;
settings.withFileDisp = 1;
settings.withSurr = 0;
settings.modelType = 1; %1 - RankSVM; 2 - SVR
settings.withModelEnsembles = 0;    % 0 - without; 1 - with
settings.withModelOptimization = 1;
settings.hyper_lambda = 20;
settings.iSTEPminForHyperOptimization = 1;
settings.MaxEvals = '1e4*dim';
settings.MaxEvalsWithSurrogate = '0'; % 1e5 for 40-D
settings.lambdaMult = 1; %see xacmes.m, will be settings.lambdaMult = 10^(1 + log2(N/10));
settings.muMult = 1;
settings.largeLambdaMinIter = 0;

settings.withDisp = 0;
settings.maxStepts = 20;
settings.maxerr = 0.45;
settings.alpha = 0.20;
settings.iterstart = 10;
%tic


dkoef = 100;
fhd=str2func('cec13_func');
for D=[10,30,50]
    
    filename = ['myfile' num2str(D) '.txt'];
    sfile = fopen(filename,'w');
    
    tic
    for i=1:10000*dkoef
        x = 0.55 + i;
        x = x + x;
        x = x / 2;
        x = x * x;
        x = sqrt(x);
        x = log(x);
        x = exp(x);
        y = x/x;    
    end;
    T0 = toc
    
    fprintf(sfile, '%f\t', T0);

    tic
    for i=1:2000*dkoef
        x = rand(D,1);
        Fit = feval(fhd,x,14);
    end;
    T1 = toc
    
    fprintf(sfile, '%f\n', T1);
    %Adapter();
    %toc
    settings.MaxEvals = 2000*dkoef;
    settings.dims = D;
    settings.funs = 14;

    for i=[0,1]
        for j=[0,1]
            T2 = 0;
            for k=[0,1]
                settings.BIPOP = i;
                settings.newRestartRules = j;
                settings.CMAactive = k;
                for itry=1:25
                    tocval = 10000;
                    while (tocval > 1000)
                        tic
                        cec2013();
                        T2(itry) = toc;
                        tocval = T2(itry);
                    end;
                    fprintf(sfile, '%f\t', T2(itry));
                end;
                T2mean = mean(T2);
                fprintf(sfile, '%f\t', T2mean);
                val = (T2mean - T1)/T0;
                fprintf(sfile, '%f\n', val);
            end;
        end;
    end;
    fclose(sfile);
end;
