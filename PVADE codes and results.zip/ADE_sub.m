function [bestmem,bestval,nfeval,Inf_matrix] = ADE_sub (fhd,D,NP,itermax,XVmin,XVmax,Record_MaxFES,fopt,j2,Inf_matrix,tipoF,tipoCR,opposition,varargin)

rand('state',sum(100*clock));

without_improve =  0;  

if length(XVmin)==1
  XVmin=repmat(XVmin,1,D);
  XVmax=repmat(XVmax,1,D);
end

XVmin=repmat(XVmin,NP,1);
XVmax=repmat(XVmax,NP,1);
pop=XVmin+(XVmax-XVmin).*rand(NP,D);
val=feval(fhd,pop',varargin{:});
nfeval=NP;
[bestval,indice] = min(val);
bestval_ant = bestval;

bestmem=pop(indice,:);

rot=(0:1:NP-1);               
rotd=(0:1:D-1);               

iter=1;
popold=pop;
CR_ant=rand;
VTR=1e-8;
cont= 1;

while ((iter < itermax) && ((bestval-fopt) >= VTR))
  previous_nfeval= nfeval;
  
  variance_pop(iter,:)=var(pop);    
  max_variance=max(variance_pop);
  diversity_norm=(D/20)*(variance_pop(iter,:)./max_variance);
  L= max(  min(0.6,1-diversity_norm), 0.3);
  
  % F
  Fdec= 0.7*(iter/itermax) + 0.2;   
  for i=1:NP
    for j=1:D  
      if rand>0.2  
        F(i,j)=L(1,j);
      else
        F(i,j)=Fdec;                   
      end
    end
  end  
       
  % CR
  if without_improve > 90  % without_improve >>10 para F14
    CR = 0.1*max(1-diversity_norm);            
  else
    CR = max(1-diversity_norm);
  end 
      
  
  popold=pop;                   
  ind=randperm(2);              

  a1=randperm(NP);             
  rt=rem(rot+ind(1),NP);        
  a2=a1(rt+1);                 
  rt=rem(rot+ind(2),NP);
  a3=a2(rt+1);                
  
  pm1=popold(a1,:);             
  pm2=popold(a2,:);             
  pm3=popold(a3,:);             
  
  
  bm=repmat(bestmem,NP,1);
  
  if length(CR) > 1
      mui=rand(NP,D)< repmat(CR,NP,1);
  else
    mui=rand(NP,D)<CR;          
  end
  
  mui=sort(mui');	          
  for i=1:NP
    n=floor(rand*D);
    rtd=rem(rotd+n,D);
    mui(:,i)=mui(rtd+1,i); 
  end
  mui=mui';			  
  mpo=mui<0.5;        

  
  if rand > 0.5  % 0.8 
    % DE/rand-to-best/1
    ui = popold + F.*(bm-popold) + F.*(pm1 - pm2);         
    %ui = bm + F.*(pm1 - pm2);        % differential variation - DE/best/1 
  else    
    % DE/rand/1
    ui = pm3 + F.*(pm1 - pm2);       % differential variation
  end
  ui = popold.*mpo + ui.*mui;     % crossover  
  
  % opposition
  if without_improve > 90  % without_improve >>10 para F14
    prob_oposition= (D/60)*diversity_norm;
  else    
    prob_oposition= (D/33.3333334)*diversity_norm;
  end  
        
  for i=1:NP
    for j=1:D        
       if rand < prob_oposition(j)  
         miu = min(ui(:,j));
         mau = max(ui(:,j));
         ui(i,j) =  miu + mau - ui(i,j);
         Op_popVar(i,j) = miu +  mau - ui(i,j);
         M(i,j)         = (miu + mau) / 2;
         if ui(i,j) < M(i,j)
           ui(i,j) = M(i,j) + (Op_popVar(i,j) - M(i,j))*rand;
         else
           ui(i,j) = Op_popVar(i,j) + (M(i,j) - Op_popVar(i,j))*rand;
         end                               
      end 
    end
  end
         
  % bounds   
  ui=(ui>XVmax).*XVmax+(ui<=XVmax).*ui;     
  ui=(ui<XVmin).*XVmin+(ui>=XVmin).*ui;
  
  tempval=feval(fhd,ui',varargin{:});
  nfeval=nfeval+NP;
  
  [best_tempval,indice]=min(tempval);
  if best_tempval < bestval,     
    bestval = best_tempval;      
    bestmem = ui(indice,:);
  end
  
  for i=1:NP,    
      if tempval(i) <= val(i),         
          pop(i,:) = ui(i,:);         
          val(i)   = tempval(i);      
      end
  end
  
  if (bestval-fopt) < VTR
    bestval = fopt;
  end
  
  if (nfeval >= Record_MaxFES(cont)) && (previous_nfeval < Record_MaxFES(cont))
      
    Inf_matrix(cont,j2) = bestval-fopt;
    cont =  cont + 1;  
  end    
  
  if (nfeval >= Record_MaxFES(end)) && (previous_nfeval <= Record_MaxFES(end))
    Inf_matrix(cont,j2) = bestval-fopt;      
    cont =  cont + 1;  
  end    
  
  if bestval == bestval_ant
    without_improve =  without_improve + 1;
  else  
    without_improve =  0;  
  end
  bestval_ant = bestval;
  iter = iter + 1;
end 
