#include "deparameterizer.h"

DEparameterizer::DEparameterizer() {}

void DEparameterizer::parameterize(ZADE *opt) {
    int o = opt->DEstrategyOptions;

    int &NPbest = opt->NPbest;
    int &NP = opt->NP;

    if (o == PSrandbinNPbest6_NP100_diffBH50perc)   { NPbest = 6; NP=100; }           // 35
}

