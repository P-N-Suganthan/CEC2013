#ifndef DEPARAMETERIZER_H
#define DEPARAMETERIZER_H

#include "zade.h"

class DEparameterizer {
protected:
    DEparameterizer();
public:
    static void parameterize(ZADE *opt);

};

enum DEtype {
    NP_noMMonlyRand1,
    NP_MMrandbest,
    NP_MMrandbestInfinitesimalMutE15, NP_MMrandbestInfinitesimalMutHalf,
    NP_MMrandWbest, NP_MMrandWbestAgeingWithEval, NP_MMrandWbestAgeingNoEval, NP_MMrandWbestAgeingNoEvalInfiMut,
    NP_MMrandbestPopCNTRL,
    //two strategies: bin, best differ on target vector, both take r1,2,3 from 1..NP
    PSrandbin,
    //two strategies: bin, best differ on target vector, first takes r1,2,3 from 1..NP2off, second those on
    PSrandBESTbin
};

enum DEstrategy_opt {
    DEstrategyDefaultOptions,
    PSrandbinNPbest10, PSrandbinNPbest5, PSrandbinNPbest4, PSrandbinNPbest6, PSrandbinNPbest7, PSrandbinNPbest8,
      PSrandbinNPbest9, PSrandbinNPbest11, PSrandbinNPbest12, PSrandbinNPbest13, PSrandbinNPbest14, PSrandbinNPbest15,
      PSrandbinNPbest16, PSrandbinNPbest17, PSrandbinNPbest18, PSrandbinNPbest19,
    PSrandbinNPbest6_NP10, PSrandbinNPbest6_NP20, PSrandbinNPbest6_NP50, PSrandbinNPbest6_NP75, PSrandbinNPbest6_NP200,
      PSrandbinNPbest6_NP30, PSrandbinNPbest6_NP300, PSrandbinNPbest6_NP80, PSrandbinNPbest6_NP120, PSrandbinNPbest6_NP150,
    PSrandbinNPbest6_NP100_MTS_e_06, PSrandbinNPbest6_NP100_MTS_e_06_pmax5, PSrandbinNPbest6_NP100_MTS_e_06_pmax3, PSrandbinNPbest6_NP100_MTS_e_06_pmax2,
    PSrandbinNPbest6_NP100_diffBH1perc, PSrandbinNPbest6_NP100_diffBH5perc, PSrandbinNPbest6_NP100_diffBH10perc,
      PSrandbinNPbest6_NP100_diffBH20perc, PSrandbinNPbest6_NP100_diffBH50perc, PSrandbinNPbest6_NP100_diffBH100perc,
      PSrandbinNPbest6_NP100_diffBH99perc, PSrandbinNPbest6_NP100_diffBH98perc, PSrandbinNPbest6_NP100_diffBHalways,
      PSrandbinNPbest6_NP100_diffBHalwaysRndNobest,
    PSrandbinNPbestPerc6_NP100_diffBHalways, PSrandbinNPbestPerc6_NP200_diffBHalways, PSrandbinNPbestPerc6_NP400_diffBHalways,
      PSrandbinNPbestPerc2_NP400_diffBHalways, PSrandbinNPbestPerc3_NP400_diffBHalways, PSrandbinNPbestPerc10_NP400_diffBHalways,
      PSrandbinNPbestPerc5_NP400_diffBHalways
};

#endif // DEPARAMETERIZER_H
