#ifndef ZADE_H
#define ZADE_H

#include "../jdeapin2008reductnp.h"

class ConstraintsEpsilonTakahama2006;
class ZADE : public jDEapin2008reduceNP {
public:
    typedef void (*EvaluateFun)(double*, double *evaluation);
    ZADE(EvaluateFun evaluate, int D, int C, int maxNFEVALs,
                double *xmin, double *xmax, unsigned int RNi=1, int DEstrategy=0, int DEstrategyOptions = 0);
    virtual ~ZADE();
    virtual void optimize(double *result, double *evaluation);

protected:
    // known mechanisms import:
    virtual void controlPopulationSizeBrestCEC12(int g);
    ConstraintsEpsilonTakahama2006 *constraintsEpsilonTakahama2006;
    int C;
    double *bestit;

    // modified methods:
    virtual void createRuntimeStorage();
    virtual void initPop();
    virtual bool isBetterFirst(const double *first, const double *second) const;

    virtual void onBeforeOptimizeOneGeneration(int &NFevals, int g);
    virtual void onAfterOptimizeOneGeneration(int &NFevals, int g);
    virtual void onBeforeOptimizeOneVector(int NFevals, int g, int i);
    virtual bool selectionTrialVsTarget(int i);

    // new methods:
    virtual void computeMutationVector(int i);
    virtual bool isBestBestPopImprovementAndDiffersSignificantly();
    virtual int getIdxStartBestPop();

    virtual void printBestStatisticsOUT();

    int DEstrategy;
    int DEstrategyOptions;

    int idxAge; //for DEstrategy == NP_MMrandWbestAgeingNoEval

    // for strat 9 - PSrandbin:
    int NPbest;
    double *bestBestPop;
    double *bestBestPopHxchg;
    int idxBestBestPop;

    friend class DEparameterizer;
    friend class UnitTestDE;
};

#endif // ZADE_H
