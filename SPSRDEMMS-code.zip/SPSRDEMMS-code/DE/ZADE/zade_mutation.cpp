#include <iostream>
using namespace std;
//#define DEBUG_ADE
void ZADE::computeMutationVector(int i) {
    //based on more strategies...
    int r1, r2, r3;

    do { r1 = (int)(random() * NP); } while (r1 == i);// select differing indices r1, r2, r3
    do { r2 = (int)(random() * NP); } while (r2 == i || r2 == r1);
    do { r3 = (int)(random() * NP); } while (r3 == i || r3 == r1 || r3 == r2);

    if (DEstrategy == PSrandbin) {//CEC 2013 (strategy 9)
        if (i < NP - NPbest)
            for (int j = 0; j < D; j++) // rand/1
                trial[j] = pop[r1*L + j] + trial[idxF] * (pop[r2*L + j] - pop[r3*L + j]);
        else
            for (int j = 0; j < D; j++) // best/1
                trial[j] = bestBestPop[j] + trial[idxF] * (pop[r2*L + j] - pop[r3*L + j]);
    }
}

