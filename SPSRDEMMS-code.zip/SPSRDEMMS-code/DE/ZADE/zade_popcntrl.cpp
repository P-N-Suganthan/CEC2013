// based on Brest et al. CEC2012, controls:
// - population size and
// - population structure/migrations (uppon population size)
void ZADE::controlPopulationSizeBrestCEC12(int g) {
    int oldNP = NP;
    const int rT=300000 / maxNFEVALs; // 300 thousand / 150 thousand = 2
    const int maxfes1=12000/rT; // /2
    const int maxfes2=60000/rT; // /2
    int it = NFevals;

    if (it >= 100 && it <= maxfes1 / 2) this-> NP = 50;
    else if (it <= maxfes1) this->NP = 10;
    else if (it < maxfes2 / 2 ) this->NP = 20;
    else if (it < maxfes2) this->NP = 10;
    else {
        if (it == maxfes2) this->NP = 80;

        int genp = maxNFEVALs / (pmax * NP);
        if (g <= genp || (NP+1)/2 < NPmin) return;

        this->NP = (NP+1) / 2;
    }

    if (oldNP == NP) return;

    //remove half of vectors (best is preserved in "best" anyway)
    for (int i = 0; i < NP; i++)
        if (isBetterFirst(pop+(NP+i)*L, pop+i*L))
            replaceFirstVectorIntoSecond(pop+(NP+i)*L, pop+i*L);
}
