//modified from jDEtevc2006
//-uses constraint handlig as proposed in:
// -- Takahama2006 (omits constraint values below 1e-6 or below epsDiminished)
// -- SIDE2012 non-viable x (nan) handling
bool ZADE::isBetterFirst(const double *first, const double *second) const {
    return constraintsEpsilonTakahama2006->isBetterFirst(first, second);
}

//modified from jDEtevc2006
//-call to "checkUpdateBest" uses proper best among best and bestBestPop
bool ZADE::selectionTrialVsTarget(int i) {
    for (int j = 0; j < D; j++) {
        if (trial[j] < xmin[j]) trial[j] = xmin[j];
        if (trial[j] > xmax[j]) trial[j] = xmax[j];
    }

    evaluate(trial, trial+idxFE); // evaluation
    NFevals++;

    if (isBetterFirst(trial, pop+i*L)) { // selection
        replaceFirstVectorIntoSecond(trial, newPop + i*L);
        checkUpdateBest(i < NP - NPbest ? best : bestBestPop); //MODIFIED LINE
        return true;
    } else replaceFirstVectorIntoSecond(pop + i*L, newPop + i*L);

    return false;
}
