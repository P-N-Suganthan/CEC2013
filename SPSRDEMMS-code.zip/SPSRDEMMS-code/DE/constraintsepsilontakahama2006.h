#ifndef CONSTRAINTSEPSILONTAKAHAMA2006_H
#define CONSTRAINTSEPSILONTAKAHAMA2006_H

class ConstraintsEpsilonTakahama2006 {
public:
    ConstraintsEpsilonTakahama2006(int NP, int L, int C, const int idxFE, const int idxC);

    virtual bool isBetterFirst(const double *first, const double *second) const;
    virtual void initEpsilonConstraint(const double *pop);
    virtual void updateEpsilonConstraint(const double *pop, double FEsPercentage);

protected:
    int NP;
    int L;
    int C;
    const int idxFE;
    const int idxC;

    double valueEpsilonConstraint, vEpsilon;

    friend class UnitTestDE;
};

#endif // CONSTRAINTSEPSILONTAKAHAMA2006_H
