#include "jdeapin2008reductnp.h"

jDEapin2008reduceNP::jDEapin2008reduceNP(EvaluateFun evaluate, int D, int NPstart, int pmax, int NPmin, int maxNFEVALs,
                                         double *xmin, double *xmax, unsigned int RNi)
                                             : jDEtevc2006(evaluate, D, NPstart, maxNFEVALs,
                                                           xmin, xmax, RNi),
                                               pmax(pmax), NPmin(NPmin) {
}

//population reduction
void jDEapin2008reduceNP::reducePopulationAPIN08(int g) {
    int genp = maxNFEVALs / (pmax * NP);
    if (g <= genp || (NP+1)/2 < NPmin) return;

    this->NP = (NP+1) / 2;

    //remove half of vectors (best is preserved in "best" anyway)
    for (int i = 0; i < NP; i++)
        if (isBetterFirst(pop+(NP+i)*L, pop+i*L))
            replaceFirstVectorIntoSecond(pop+(NP+i)*L, pop+i*L);
}

void jDEapin2008reduceNP::onBeforeOptimizeOneGeneration(int &NFevals, int g) {
    reducePopulationAPIN08(g);
}
