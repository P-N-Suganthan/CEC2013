#ifndef JDEAPIN2008REDUCTNP_H
#define JDEAPIN2008REDUCTNP_H

#include "jdetevc2006.h"
class jDEapin2008reduceNP : public jDEtevc2006 {
public:
    // Added parameters: NPstart and pmax!
    jDEapin2008reduceNP(EvaluateFun evaluate, int D, int NPstart, int pmax, int NPmin, int maxNFEVALs,
                        double *xmin, double *xmax, unsigned int RNi=1);

protected:
    virtual void reducePopulationAPIN08(int g);
    virtual void onBeforeOptimizeOneGeneration(int &NFevals, int g);

    int pmax;
    int NPmin;
};

#endif // JDEAPIN2008REDECTNP_H
