#include <cmath>
#include "initcec2013.h"
#include "cec2013_test_func.cpp"

//const int NFUNCS = 28;
//const int NRUNS = 51;// 25
const int cec2013_D[] = {10, 30, 50};
//int scale = 10000;//10000;
//int MAX_NFEVALS[] = {cec2013_D[0]*scale, cec2013_D[1]*scale, cec2013_D[2]*scale};
static int xmin1=-100;
static int xmax1=100;

void test_func(double *, double *,int,int,int);

double *OShift,*M,*y,*z,*x_bound;
int ini_flag=0,n_flag,func_flag;

//funNr is 1-based!!!
extern int funNr;

extern int currentNF;

void evaluateCEC2013(double *x, double *c) {
    int n,m,func_num=funNr;
    m=1;//was 2
    //f=(double *)malloc(sizeof(double)  *  m);

    n=currentNF%3==0?10:(currentNF%3==1?30:50);

    test_func(x, c, n, m, func_num);
}

void initXminXmaxCEC2013(double *xmin, double *xmax, int D) {
    for (int i = 0; i < D; i++) { // 1. OK
        xmin[i]=xmin1;
        xmax[i]=xmax1;
    }
}

double getOffsetCEC2013(int func_num) {
    switch(func_num)
    {
    case 1:
        return -1400.0;

    case 2:
        return -1300.0;

    case 3:
        return -1200.0;

    case 4:
        return -1100.0;

    case 5:
        return -1000.0;

    case 6:
        return -900.0;

    case 7:
        return -800.0;

    case 8:
        return -700.0;

    case 9:
        return -600.0;

    case 10:
        return -500.0;

    case 11:
        return -400.0;

    case 12:
        return -300.0;

    case 13:
        return -200.0;

    case 14:
        return -100.0;

    case 15:
        return 100.0;

    case 16:
        return 200.0;

    case 17:
        return 300.0;

    case 18:
        return 400.0;

    case 19:
        return 500.0;

    case 20:
        return 600.0;

    case 21:
        return 700.0;

    case 22:
        return 800.0;

    case 23:
        return 900.0;

    case 24:
        return 1000.0;

    case 25:
        return 1100.0;

    case 26:
        return 1200.0;

    case 27:
        return 1300.0;

    case 28:
        return 1400.0;
    }

    return -1e+6; // canary safely: a bad big value
}
