#ifndef INITCEC2013_H
#define INITCEC2013_H

extern int NFUNCS;
extern int NRUNS;
extern int scale;
extern int MAX_NFEVALS[];


extern int funNr;
extern const int cec2013_D[];
void evaluateCEC2013(double *x, double *c);
void initXminXmaxCEC2013(double *xmin, double *xmax, int D);
double getOffsetCEC2013(int func_num);

#endif // INITCEC2013_H
