#include "runapp/runapp.h"

int main(int argc, char**argv) {
    runApp(argc, argv);

    return 0;
}
