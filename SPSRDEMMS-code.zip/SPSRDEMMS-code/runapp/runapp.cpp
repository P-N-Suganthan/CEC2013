#include "runapp.h"
#include "runappcecoptimization.h"
#include "ext.h"

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <iostream>


void runOptimizationOnCEC(int argc, char**argv) {
#ifdef EXT_RUNCEC_CUTPOINT
    ext_runCEC_cutpoint(argc, argv); // include possible extensions  (none)
#endif

    RunAppCECOptimization opt(argc, argv);
    opt.runOptimizationOnAllCECFunctions();
    exit(0); // skip destructors, etc.
}

void runApp(int argc, char**argv) {
#ifdef EXT_RUNAPP_CUTPOINT
    printf("\nCEC2011??\n");
    ext_runApp_cutpoint(argc, argv); // include possible extensions (none)
#endif

    bool CEC2013 = argc > 1 && strcmp(argv[1], "CEC2013") == 0;

    if (CEC2013)
        runOptimizationOnCEC(argc, argv);
    else
        std::cout << "Usage: " << argv[0] << " CEC2013" << std::endl;
}
