#ifndef RUNAPP_H
#define RUNAPP_H

void runApp(int argc, char**argv);

#endif // RUNAPP_H
