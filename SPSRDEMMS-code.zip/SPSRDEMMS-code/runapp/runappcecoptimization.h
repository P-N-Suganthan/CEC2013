#ifndef RUNAPPCECOPTIMIZATION_H
#define RUNAPPCECOPTIMIZATION_H

#include <time.h>
#include <vector>
class RunAppCECOptimization {
public:
    RunAppCECOptimization(int &argc, char**&argv);
    virtual ~RunAppCECOptimization();

    virtual void runOptimizationOnAllCECFunctions();

protected:
    bool isCEC2013;

    virtual void reportCECAssessmentForOneFunction(int funNr, int NF);
    virtual void optimizeOneCECFunction(int funNr, int max_nfevals, std::vector<double> &bestsAtTheEnd);

    virtual double workerOptimizeCECFunction(int funNr, int max_nfevals, int RNi);

    virtual void printFunctionStatistics(int funNr, int NF, std::vector<double> &bestsAtTheEnd, double time);
    double diffclock_min(const clock_t &clock1, const clock_t &clock2);

    int funStart, funEnd;
    int nfStart, nfEnd;
    int rniStart, rniEnd;
    int DEstrategy;
    int DEstrategyOptions;
};

#endif // RUNAPPCECOPTIMIZATION_H
