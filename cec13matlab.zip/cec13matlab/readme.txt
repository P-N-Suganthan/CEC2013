/*
  CEC13 Test Function Suite 
  Jane Jing Liang (email: liangjing@zzu.edu.cn) 
  8th Jan. 2013
*/

1. run the following command in Matlab window:
   mex cec13_func.cpp -DWINDOWS
2. Then you can use the test functions as the following example:
   f = cec13_func(x,func_num); 
   here x is a D*pop_size matrix.
3. main.m is an example test code with PSO algorithm.

